module.exports = {
    HOST: "bons133t.beget.tech",
    USER: "bons133t_mirteam",
    PASSWORD: "&yJFTN6l",
    DB: "bons133t_mirteam",
    dialect: "mysql",
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  };