module.exports = (sequelize, Sequelize) => {
    const User = sequelize.define("user", {
        id: {
            type: Sequelize.INTEGER,
            primaryKey: true
        },
        login: {
            type: Sequelize.STRING
        },
        password: {
            type: Sequelize.STRING
        },
        fcs: {
            type: Sequelize.STRING
        },
        age: {
            type: Sequelize.INTEGER
        },
        course: {
            type: Sequelize.INTEGER
        },
        institute: {
            type: Sequelize.STRING
        },
        groupID: {
            type: Sequelize.STRING
        },
        email: {
            type: Sequelize.STRING
        },
        instagram: {
            type: Sequelize.STRING
        },
        pnumber: {
            type: Sequelize.STRING
        },
        stnumber: {
            type: Sequelize.INTEGER
        },
        inn: {
            type: Sequelize.INTEGER
        },
        snils: {
            type: Sequelize.INTEGER
        },
        bshifr: {
            type: Sequelize.STRING
        },
        comment: {
            type: Sequelize.STRING
        }
    });

    return User;
};